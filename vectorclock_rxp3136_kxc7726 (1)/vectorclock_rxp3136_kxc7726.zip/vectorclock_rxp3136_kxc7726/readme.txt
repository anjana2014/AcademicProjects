#Rishitha Patel-1001863136
#keerthi chittineni-1001967726

To run the vector_clock project:

1.Open the project folder ->open the command prompt for vector_clock
2.run python app.py command.
3.After that  we can see all the operations performed by vector clock with the given vectors with respect to the timestamps



