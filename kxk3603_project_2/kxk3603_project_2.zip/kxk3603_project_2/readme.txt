
1. Please fill the details below before you submit

Student Name: Krishna anjana Killamsetty
UTA Student ID: 1002033603
Student NetID: kxk3603


2. Replace <netId> in the root folder name with your netId



----------------------------------
|  Important Points to Remember  |
----------------------------------

1. DO NOT CHANGE the directory structure.
2. The run_code.sh file contains the commands to execute your python code.
3. Make this file executable on your respective OS and then run it. It will execute all the python files.
4. Before submission you must run the run_code.sh file and make sure it is working and you are able to execute all your code files. The GTAs will run this file to verify your code runs.

5. Please heavily comment your code so that it is easy for the GTAs to understand and grade it.


Command to run the script are below:

Mac/Linux:
./run_code.sh

Windows:
bash ./run_code.sh

