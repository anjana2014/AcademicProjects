
echo 'Starting script to execute all python files\n'

python3 Q1/Q1_AB.py
python3 Q1/Q1_C.py
python3 Q1/Q1_D.py

echo '==========================================================================='

python3 Q2/Q2_AB.py
python3 Q2/Q2_C.py
python3 Q2/Q2_D.py

echo '==========================================================================='

python3 Q3/Q3_AB.py
python3 Q3/Q3_C.py
python3 Q3/Q3_D.py

echo 'END\n'